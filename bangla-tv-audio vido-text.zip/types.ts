
export enum InputType {
  TEXT = 'TEXT',
  VIDEO = 'VIDEO',
  AUDIO = 'AUDIO'
}

export interface ThumbnailData {
  line1: string;
  line2: string;
  copy: string;
}

export interface NewsOutput {
  youtube: {
    headlines: string[];
    description: string;
    tags: string[];
  };
  facebook: {
    headlines: string[];
    description: string;
    hashtags: string[];
  };
  thumbnails: ThumbnailData[];
  graphics: {
    breakingStrap: string;
    lowerThird: string;
  };
  extractedText?: string;
}

export interface ProcessingState {
  loading: boolean;
  error: string | null;
  result: NewsOutput | null;
}

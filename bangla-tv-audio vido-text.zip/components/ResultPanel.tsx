
import React from 'react';
import { NewsOutput, ThumbnailData } from '../types';

interface ResultPanelProps {
  result: NewsOutput;
}

const CopyButton: React.FC<{ text: string }> = ({ text }) => {
  const [copied, setCopied] = React.useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <button
      onClick={handleCopy}
      className={`p-2 rounded-lg transition-colors flex items-center gap-1 text-xs font-semibold ${
        copied ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
      }`}
    >
      {copied ? (
        <>
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
          </svg>
          কপি হয়েছে
        </>
      ) : (
        <>
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" />
          </svg>
          কপি
        </>
      )}
    </button>
  );
};

const SectionHeader: React.FC<{ icon: React.ReactNode; title: string; color: string }> = ({ icon, title, color }) => (
  <div className={`flex items-center gap-3 mb-6 p-3 rounded-xl border ${color} bg-white shadow-sm`}>
    <div className={`p-2 rounded-lg text-white ${color.replace('border-', 'bg-').split(' ')[0]}`}>
      {icon}
    </div>
    <h3 className="text-xl font-bold text-slate-800">{title}</h3>
  </div>
);

const ResultPanel: React.FC<ResultPanelProps> = ({ result }) => {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      
      {/* YouTube Section */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
        <SectionHeader 
          icon={<svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.377.505 9.377.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>} 
          title="YouTube News" 
          color="border-red-200 text-red-600"
        />
        
        <div className="space-y-6">
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Headline Variations</label>
            <div className="space-y-3">
              {result.youtube.headlines.map((h, i) => (
                <div key={i} className="flex justify-between items-start gap-4 p-3 bg-slate-50 rounded-lg border border-slate-100 hover:border-red-200 transition-colors">
                  <span className="text-slate-800 font-medium leading-relaxed">{h}</span>
                  <CopyButton text={h} />
                </div>
              ))}
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-2">
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider">Description</label>
              <CopyButton text={result.youtube.description} />
            </div>
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 text-slate-700 text-sm leading-relaxed max-h-48 overflow-y-auto whitespace-pre-wrap">
              {result.youtube.description}
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Tags</label>
            <div className="flex flex-wrap gap-2">
              {result.youtube.tags.map((tag, i) => (
                <span key={i} className="px-3 py-1 bg-white border border-slate-200 rounded-full text-xs font-medium text-slate-600">
                  {tag}
                </span>
              ))}
              <div className="ml-auto">
                <CopyButton text={result.youtube.tags.join(', ')} />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Facebook Section */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
        <SectionHeader 
          icon={<svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>} 
          title="Facebook News" 
          color="border-blue-200 text-blue-600"
        />

        <div className="space-y-6">
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Headline Variations</label>
            <div className="space-y-3">
              {result.facebook.headlines.map((h, i) => (
                <div key={i} className="flex justify-between items-start gap-4 p-3 bg-slate-50 rounded-lg border border-slate-100 hover:border-blue-200 transition-colors">
                  <span className="text-slate-800 font-medium leading-relaxed">{h}</span>
                  <CopyButton text={h} />
                </div>
              ))}
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-2">
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider">Description</label>
              <CopyButton text={result.facebook.description} />
            </div>
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 text-slate-700 text-sm leading-relaxed max-h-48 overflow-y-auto whitespace-pre-wrap">
              {result.facebook.description}
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Hashtags</label>
            <div className="flex flex-wrap gap-2">
              {result.facebook.hashtags.map((tag, i) => (
                <span key={i} className="px-3 py-1 bg-blue-50 border border-blue-100 rounded-full text-xs font-semibold text-blue-700">
                  {tag}
                </span>
              ))}
              <div className="ml-auto">
                <CopyButton text={result.facebook.hashtags.join(' ')} />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Graphics Section */}
      <div className="lg:col-span-2 bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
        <SectionHeader 
          icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>} 
          title="Thumbnail & TV Graphics" 
          color="border-purple-200 text-purple-600"
        />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
          {result.thumbnails.map((thumb, i) => (
            <div key={i} className="bg-slate-900 rounded-xl p-6 relative group overflow-hidden border-2 border-transparent hover:border-purple-400 transition-all shadow-lg">
              <div className="absolute top-2 right-2 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-opacity z-10">
                <CopyButton text={thumb.copy} />
              </div>
              <div className="absolute inset-0 bg-gradient-to-br from-purple-900/40 to-black/80 pointer-events-none"></div>
              <div className="relative z-0">
                <div className="mb-4">
                  <span className="bg-red-600 text-white text-[10px] font-bold px-2 py-1 rounded uppercase tracking-tighter">Thumbnail {i + 1}</span>
                </div>
                <div className="space-y-2">
                  <p className="text-xl font-black text-yellow-400 leading-tight drop-shadow-lg">{thumb.line1}</p>
                  <p className="text-2xl font-black text-white leading-tight drop-shadow-lg">{thumb.line2}</p>
                </div>
                <div className="mt-6 pt-4 border-t border-white/10">
                  <p className="text-xs text-slate-400 font-medium">Text Copy:</p>
                  <p className="text-[10px] text-white/70 mt-1 line-clamp-2">{thumb.copy}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-red-50 border border-red-100 rounded-xl p-5">
            <div className="flex justify-between items-center mb-3">
              <h4 className="text-sm font-bold text-red-700 uppercase tracking-widest">Breaking Strap</h4>
              <CopyButton text={result.graphics.breakingStrap} />
            </div>
            <div className="bg-red-600 text-white font-black px-4 py-3 rounded shadow-inner text-xl text-center uppercase tracking-wider">
              {result.graphics.breakingStrap}
            </div>
          </div>
          
          <div className="bg-slate-800 border border-slate-700 rounded-xl p-5">
            <div className="flex justify-between items-center mb-3">
              <h4 className="text-sm font-bold text-slate-300 uppercase tracking-widest">Lower Third</h4>
              <CopyButton text={result.graphics.lowerThird} />
            </div>
            <div className="bg-slate-700 border-l-8 border-red-600 text-white font-bold px-4 py-3 rounded shadow-inner text-lg">
              {result.graphics.lowerThird}
            </div>
          </div>
        </div>
      </div>

      {/* Extracted/Source Area */}
      {result.extractedText && (
        <div className="lg:col-span-2 bg-slate-100 rounded-xl p-6 border border-slate-200">
          <div className="flex justify-between items-center mb-4">
            <h4 className="text-sm font-bold text-slate-500 uppercase tracking-widest">Extracted Content Context</h4>
            <CopyButton text={result.extractedText} />
          </div>
          <p className="text-slate-600 text-sm leading-relaxed italic">
            {result.extractedText}
          </p>
        </div>
      )}
    </div>
  );
};

export default ResultPanel;

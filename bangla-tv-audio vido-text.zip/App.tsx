
import React, { useState, useCallback } from 'react';
import { generateNewsContent } from './geminiService';
import { InputType, ProcessingState, NewsOutput } from './types';
import ResultPanel from './components/ResultPanel';

const App: React.FC = () => {
  const [inputType, setInputType] = useState<InputType>(InputType.TEXT);
  const [textInput, setTextInput] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [state, setState] = useState<ProcessingState>({
    loading: false,
    error: null,
    result: null
  });

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        const base64String = (reader.result as string).split(',')[1];
        resolve(base64String);
      };
      reader.onerror = (error) => reject(error);
    });
  };

  const handleProcess = async () => {
    setState({ loading: true, error: null, result: null });
    try {
      let result: NewsOutput;
      if (inputType === InputType.TEXT) {
        if (!textInput.trim()) throw new Error("অনুগ্রহ করে নিউজ স্ক্রিপ্ট দিন।");
        result = await generateNewsContent(textInput, false);
      } else {
        if (!file) throw new Error("অনুগ্রহ করে মিডিয়া ফাইল সিলেক্ট করুন।");
        const base64Data = await fileToBase64(file);
        result = await generateNewsContent(
          { data: base64Data, mimeType: file.type },
          true
        );
      }
      setState({ loading: false, error: null, result });
    } catch (err: any) {
      setState({ loading: false, error: err.message || "একটি ত্রুটি ঘটেছে। আবার চেষ্টা করুন।", result: null });
    }
  };

  const reset = () => {
    setState({ loading: false, error: null, result: null });
    setTextInput('');
    setFile(null);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center p-4 md:p-8">
      {/* Header */}
      <header className="w-full max-w-5xl flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-red-600 rounded-lg flex items-center justify-center text-white font-bold text-xl shadow-lg">
            BT
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-800">Elite News AI Engine</h1>
            <p className="text-sm text-slate-500 font-medium">Powering Bangla TV Social Media & Graphics</p>
          </div>
        </div>
        <div className="flex bg-white rounded-full p-1 shadow-sm border border-slate-200">
          {(Object.keys(InputType) as Array<keyof typeof InputType>).map((type) => (
            <button
              key={type}
              onClick={() => setInputType(InputType[type])}
              className={`px-6 py-2 rounded-full text-sm font-semibold transition-all ${
                inputType === InputType[type]
                  ? 'bg-red-600 text-white shadow-md'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {type === 'TEXT' ? 'স্ক্রিপ্ট' : type === 'VIDEO' ? 'ভিডিও' : 'অডিও'}
            </button>
          ))}
        </div>
      </header>

      {/* Main Content Area */}
      <main className="w-full max-w-5xl flex flex-col gap-6">
        {/* Input Card */}
        {!state.result && (
          <div className="bg-white rounded-2xl shadow-xl border border-slate-100 p-6 md:p-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            {inputType === InputType.TEXT ? (
              <textarea
                value={textInput}
                onChange={(e) => setTextInput(e.target.value)}
                placeholder="এখানে আপনার নিউজের স্ক্রিপ্ট লিখুন..."
                className="w-full h-64 p-4 border border-slate-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-red-500 outline-none transition-all text-lg resize-none"
              />
            ) : (
              <div className="flex flex-col items-center justify-center border-2 border-dashed border-slate-300 rounded-xl h-64 hover:border-red-400 transition-colors group cursor-pointer relative">
                <input
                  type="file"
                  accept={inputType === InputType.VIDEO ? "video/*" : "audio/*"}
                  onChange={(e) => setFile(e.target.files?.[0] || null)}
                  className="absolute inset-0 opacity-0 cursor-pointer"
                />
                <div className="text-center p-4">
                  <div className="mb-4 text-slate-400 group-hover:text-red-500 transition-colors">
                    <svg className="w-16 h-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                    </svg>
                  </div>
                  <p className="text-lg font-semibold text-slate-700">
                    {file ? file.name : `আপনার ${inputType === InputType.VIDEO ? 'ভিডিও' : 'অডিও'} ফাইলটি এখানে ড্রপ করুন`}
                  </p>
                  <p className="text-sm text-slate-400 mt-2">Maximum file size 50MB</p>
                </div>
              </div>
            )}

            <div className="mt-8 flex justify-center">
              <button
                disabled={state.loading}
                onClick={handleProcess}
                className={`flex items-center gap-3 px-12 py-4 rounded-xl text-lg font-bold shadow-lg transition-all transform active:scale-95 ${
                  state.loading
                    ? 'bg-slate-300 cursor-not-allowed text-slate-500'
                    : 'bg-red-600 text-white hover:bg-red-700 hover:shadow-red-200 shadow-xl'
                }`}
              >
                {state.loading ? (
                  <>
                    <svg className="animate-spin h-6 w-6 text-white" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    প্রসেসিং হচ্ছে...
                  </>
                ) : (
                  <>
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
                    </svg>
                    কন্টেন্ট জেনারেট করুন
                  </>
                )}
              </button>
            </div>

            {state.error && (
              <p className="mt-4 text-center text-red-600 font-medium">{state.error}</p>
            )}
          </div>
        )}

        {/* Result Area */}
        {state.result && (
          <div className="animate-in fade-in zoom-in-95 duration-700">
            <div className="mb-6 flex justify-between items-center">
              <h2 className="text-xl font-bold text-slate-800">জেনারেটেড নিউজ কন্টেন্ট</h2>
              <button 
                onClick={reset}
                className="px-4 py-2 text-sm font-semibold text-red-600 border border-red-200 rounded-lg hover:bg-red-50 transition-colors"
              >
                নতুন করে শুরু করুন
              </button>
            </div>
            <ResultPanel result={state.result} />
          </div>
        )}
      </main>

      {/* Footer Info */}
      <footer className="mt-12 text-slate-400 text-sm pb-8">
        © {new Date().getFullYear()} Bangla TV Elite News AI. All Rights Reserved.
      </footer>
    </div>
  );
};

export default App;

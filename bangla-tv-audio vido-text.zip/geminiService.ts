
import { GoogleGenAI, Type } from "@google/genai";
import { NewsOutput } from "./types";

const MASTER_PROMPT = `
আপনি “বাংলা টিভি”-এর জন্য কাজ করা একজন Elite Bangla News AI Engine। 
আপনার দায়িত্ব হলো সরবরাহকৃত ইনপুট (টেক্সট, ভিডিও বা অডিও) বিশ্লেষণ করে হাই-ইমপ্যাক্ট নিউজ কন্টেন্ট তৈরি করা।

অনুসরণীয় নিয়মাবলী:
১. বাংলাদেশের মানুষের আগ্রহ (দ্রব্যমূল্য, চাকরি, রাজনীতি, অপরাধ, আবহাওয়া, বিদ্যুৎ/গ্যাস) অগ্রাধিকার দিন।
২. প্রমিত সাংবাদিকতাভিত্তিক বাংলা ব্যবহার করুন। অতিরঞ্জন বা গুজব বর্জন করুন। 
৩. Clickbait নয়, কিন্তু High CTR নিশ্চিত করুন।
৪. “বাংলা টিভি” ব্র্যান্ড-সেইফ থাকতে হবে।

আউটপুট অবশ্যই নিচের JSON ফরম্যাটে হতে হবে:
{
  "youtube": {
    "headlines": ["Headline 1", "Headline 2", "Headline 3"],
    "description": "150-250 words with hook and CTA",
    "tags": ["tag1", "tag2"]
  },
  "facebook": {
    "headlines": ["Headline 1", "Headline 2", "Headline 3"],
    "description": "100-150 words with daily life impact and a question",
    "hashtags": ["#tag1", "#tag2"]
  },
  "thumbnails": [
    {"line1": "Short Line 1", "line2": "Short Line 2", "copy": "Combined 12-15 words copy"},
    {"line1": "...", "line2": "...", "copy": "..."},
    {"line1": "...", "line2": "...", "copy": "..."},
    {"line1": "...", "line2": "...", "copy": "..."},
    {"line1": "...", "line2": "...", "copy": "..."}
  ],
  "graphics": {
    "breakingStrap": "3-5 words strap",
    "lowerThird": "1 line info text"
  },
  "extractedText": "Input content summary or transcription"
}
`;

export const generateNewsContent = async (
  input: string | { data: string; mimeType: string },
  isMedia: boolean
): Promise<NewsOutput> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const contents: any = [];
  
  if (isMedia && typeof input !== 'string') {
    contents.push({
      inlineData: input
    });
    contents.push({
      text: MASTER_PROMPT + "\n\nউপরে দেয়া মিডিয়া ফাইল থেকে তথ্য সংগ্রহ করে আউটপুট জেনারেট করুন।"
    });
  } else {
    contents.push({
      text: MASTER_PROMPT + `\n\nনিউজ স্ক্রিপ্ট: ${input}`
    });
  }

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: { parts: contents },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          youtube: {
            type: Type.OBJECT,
            properties: {
              headlines: { type: Type.ARRAY, items: { type: Type.STRING } },
              description: { type: Type.STRING },
              tags: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ["headlines", "description", "tags"]
          },
          facebook: {
            type: Type.OBJECT,
            properties: {
              headlines: { type: Type.ARRAY, items: { type: Type.STRING } },
              description: { type: Type.STRING },
              hashtags: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ["headlines", "description", "hashtags"]
          },
          thumbnails: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                line1: { type: Type.STRING },
                line2: { type: Type.STRING },
                copy: { type: Type.STRING }
              },
              required: ["line1", "line2", "copy"]
            }
          },
          graphics: {
            type: Type.OBJECT,
            properties: {
              breakingStrap: { type: Type.STRING },
              lowerThird: { type: Type.STRING }
            },
            required: ["breakingStrap", "lowerThird"]
          },
          extractedText: { type: Type.STRING }
        },
        required: ["youtube", "facebook", "thumbnails", "graphics"]
      }
    }
  });

  try {
    const data = JSON.parse(response.text || '{}');
    return data as NewsOutput;
  } catch (e) {
    throw new Error("Failed to parse AI response. Please try again.");
  }
};
